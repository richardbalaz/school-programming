#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

struct Position {
    int line;
    int pos;
};

int main() {

    int lineCtr = 1, posCtr = 1;

    ifstream file1;
    ofstream file2;
    file1.open("mapa.txt", ios::in);
    file2.open("oprava.txt", ios::out);

    vector<string> vline;
    vector<Position> vPos;
    string sline;

    while(!file1.eof()) {

        getline(file1, sline);
        cout << sline << endl;



        for (int i = 0; i < sline.length(); i++, posCtr++) {
            if (sline[i] == '.') {
                Position pos;
                pos.line = lineCtr;
                pos.pos = posCtr;

                vPos.push_back(pos);

                sline[i] = 'o';
            }
        }

        vline.push_back(sline);

        file2 << vline[lineCtr-1] << endl;

        lineCtr++;
        posCtr = 1;

    }

    cout << "Pozicie su:" << endl;

    for (int i = 0; i < vPos.size(); i++) {
        cout << "[" << vPos[i].line << "," << vPos[i].pos << "]" << endl;
    }

    return 0;
}
